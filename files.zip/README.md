# 🛒 Market Basket Analysis System

A machine learning web application that performs **Association Rule Mining** using the **Apriori Algorithm** to discover relationships between products frequently purchased together.

---

## 🚀 Quick Start

### 1. Install dependencies
```bash
pip install -r requirements.txt
```

### 2. Run the application
```bash
python app.py
```

### 3. Open in browser
```
http://localhost:5000
```

---

## 📂 Project Structure

```
mba_app/
├── app.py                  # Flask backend — all ML logic + API routes
├── requirements.txt        # Python dependencies
├── README.md
├── templates/
│   └── index.html          # Full single-page frontend
├── uploads/                # Temporarily stores uploaded CSV files
└── outputs/                # Exported association rules CSV
```

---

## 📋 CSV Format

Your dataset should be a CSV file with transactions. Supported formats:

**Format A — with header:**
```
TransactionID,Items
1,"Bread, Milk"
2,"Bread, Butter"
3,"Milk, Butter, Eggs"
```

**Format B — raw (no header):**
```
Bread,Milk
Bread,Butter
Milk,Butter,Eggs
```

---

## ⚙️ Parameters

| Parameter      | Description                                    | Default |
|----------------|------------------------------------------------|---------|
| Min Support    | Fraction of transactions that contain the itemset | 0.10 |
| Min Confidence | How often the rule is correct                  | 0.50    |
| Min Lift       | Ratio of observed vs expected frequency (>1 = positive correlation) | 1.0 |

---

## 📊 Output

### Frequent Itemsets
All combinations of items that appear in at least `min_support` fraction of transactions.

### Association Rules
Rules of the form **IF {A} → THEN {B}** with:
- **Support** — how common is the combination
- **Confidence** — how likely is B given A
- **Lift** — how much more likely than random chance

### Charts
- Top 15 most frequent items (bar chart)
- Support vs Confidence scatter (colored by Lift)
- Confidence heatmap (antecedents vs consequents)
- Top rules by Lift score

---

## 🧠 ML Techniques

1. **Apriori Algorithm** — finds frequent itemsets efficiently using a breadth-first search with pruning
2. **One-Hot Encoding** (TransactionEncoder) — converts transaction lists to binary matrix
3. **Association Rule Metrics** — Support, Confidence, Lift
4. **Visualization** — matplotlib + seaborn for chart generation

---

## 🔧 API Endpoints

| Method | Endpoint              | Description                         |
|--------|-----------------------|-------------------------------------|
| GET    | `/`                   | Main application UI                 |
| POST   | `/api/analyze`        | Upload CSV and run Apriori analysis |
| GET    | `/api/download_rules` | Download rules as CSV               |
| GET    | `/api/sample_dataset` | Download sample transaction CSV     |

### POST `/api/analyze` — Form fields

| Field          | Type  | Description                 |
|----------------|-------|-----------------------------|
| `file`         | File  | CSV file upload             |
| `min_support`  | float | Minimum support threshold   |
| `min_confidence` | float | Minimum confidence threshold |
| `min_lift`     | float | Minimum lift threshold      |

---

## 🔮 Optional Extensions

- **K-Means Clustering** — customer segmentation (add to app.py)
- **Real-time recommendations** — serve rules via REST API
- **Database integration** — swap CSV for PostgreSQL/MySQL queries
- **E-commerce plugin** — integrate with Shopify/WooCommerce APIs

---

## 📦 Tech Stack

| Layer     | Technology                          |
|-----------|-------------------------------------|
| Backend   | Python 3.10+ · Flask               |
| ML        | mlxtend (Apriori) · pandas · numpy  |
| Viz       | matplotlib · seaborn                |
| Frontend  | HTML5 · CSS3 · Vanilla JS           |
| Charts    | matplotlib rendered to base64 PNG   |
